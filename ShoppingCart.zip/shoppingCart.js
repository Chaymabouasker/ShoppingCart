const like=document.getElementsByClassName('fa fa-heart')
for (let i of like) {
    i.addEventListener('click',function(){
        i.classList.toggle("new")
    })   
}

var RemoveCartItemBtn=document.getElementsByClassName('rmv-btn')
for (var i=0; i < RemoveCartItemBtn.length; i++){
    var button = RemoveCartItemBtn[i]
    button.addEventListener('click', function(event){
     var buttonclicked=event.target
       buttonclicked.closest('.product').remove()
       updateCartTotal()
    })
}

var quantityInputs = document.getElementsByClassName('quantity-input')
for(var i=0; i < quantityInputs.length; i++){
    var input = quantityInputs[i]
    input.addEventListener('change' , function(event){
        var input = event.target
        if ((input.value)<1 ){
            alert("you can't go below 1")
            input.value=1
        }
        updateCartTotal()

    })


}

function updateCartTotal(){
    var cartItemContainer = document.getElementsByClassName('items')[0]
    var cartRows = cartItemContainer.getElementsByClassName('product')
    var total=0
    for(var i=0; i < cartRows.length; i++){
        var cartRow = cartRows[i]
        var priceElement = document.getElementsByClassName('price-input')[i]
        var quantityElement = document.getElementsByClassName('quantity-input')[i]
        var price =parseFloat( priceElement.innerText.replace('$',''))
        var quantity = quantityElement.value
        total = total+(price*quantity)
        
    }
    document.getElementsByClassName('total-f')[0].innerText='$'+total
    document.getElementsByClassName('total-f')[1].innerText='$'+total
}

